import React, { useState, useCallback, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Platform } from "react-native";
import { useRouter, Stack } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Picker } from "@react-native-picker/picker";
import DateTimePicker, { DateTimePickerEvent } from "@react-native-community/datetimepicker";
import { FontAwesome5 } from "@expo/vector-icons";

// Cores (mantendo o padrão Mottu)
const MOTTU_BLACK = "#121212";
const MOTTU_GREEN = "#00EF7F";
const MOTTU_WHITE = "#FFFFFF";
const MOTTU_GRAY = "#333333";
const MOTTU_LIGHT_GRAY = "#A0A0A0";

const MOTOS_STORAGE_KEY = "@MinhasMotos:key";

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  ultimaLocalizacao: string;
  pontoLeituraRfid?: string;
  horarioUltimaLeitura?: string;
  statusRfid?: string;
  historico?: Array<{data: string, local: string, pontoRfid?: string}>;
}

// Pontos de Leitura RFID Simulados
const PONTOS_RFID_SIMULADOS = [
  "Portaria - Entrada",
  "Portaria - Saída",
  "Pátio A - Leitor 01",
  "Pátio A - Leitor 02",
  "Pátio B - Leitor 01",
  "Pátio B - Leitor 02",
  "Oficina - Entrada",
  "Oficina - Saída",
  "Zona de Carga - Leitor 01",
  "Lavagem - Leitor 01",
];

export default function RegistrarEventoRfidScreen() {
  const router = useRouter();
  const [motos, setMotos] = useState<Moto[]>([]);
  const [selectedMotoId, setSelectedMotoId] = useState<string | undefined>();
  const [selectedPontoRfid, setSelectedPontoRfid] = useState<string>(PONTOS_RFID_SIMULADOS[0]);
  const [eventDate, setEventDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const carregarMotos = useCallback(async () => {
    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      if (motosSalvas !== null) {
        setMotos(JSON.parse(motosSalvas));
      }
    } catch (e) {
      Alert.alert("Erro", "Não foi possível carregar a lista de motos.");
    }
  }, []);

  useEffect(() => {
    carregarMotos();
  }, [carregarMotos]);

  const onDateChange = (event: DateTimePickerEvent, selectedDate?: Date) => {
    const currentDate = selectedDate || eventDate;
    setShowDatePicker(Platform.OS === "ios");
    setEventDate(currentDate);
    if (Platform.OS !== "ios") {
        setShowTimePicker(true); // Show time picker right after date on Android
    }
  };

  const onTimeChange = (event: DateTimePickerEvent, selectedTime?: Date) => {
    const currentTime = selectedTime || eventDate;
    setShowTimePicker(Platform.OS === "ios");
    // Combine date and time
    const newDateTime = new Date(eventDate);
    newDateTime.setHours(currentTime.getHours());
    newDateTime.setMinutes(currentTime.getMinutes());
    setEventDate(newDateTime);
  };

  const handleRegistrarEvento = async () => {
    if (!selectedMotoId) {
      Alert.alert("Seleção Necessária", "Por favor, selecione uma moto.");
      return;
    }

    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      let motosExistentes: Moto[] = motosSalvas ? JSON.parse(motosSalvas) : [];
      
      const motoIndex = motosExistentes.findIndex(m => m.id === selectedMotoId);
      if (motoIndex === -1) {
        Alert.alert("Erro", "Moto selecionada não encontrada.");
        return;
      }

      const motoAtualizada = { ...motosExistentes[motoIndex] };
      motoAtualizada.ultimaLocalizacao = selectedPontoRfid; // Ou uma lógica para mapear ponto RFID para localização mais genérica
      motoAtualizada.pontoLeituraRfid = selectedPontoRfid;
      motoAtualizada.horarioUltimaLeitura = eventDate.toLocaleString("pt-BR");
      motoAtualizada.statusRfid = "Em Movimentação"; // Exemplo de status

      if (!motoAtualizada.historico) {
        motoAtualizada.historico = [];
      }
      motoAtualizada.historico.unshift({
        data: eventDate.toLocaleString("pt-BR"),
        local: selectedPontoRfid, // Usando o ponto RFID como local no histórico
        pontoRfid: selectedPontoRfid,
      });
      // Manter apenas os últimos X registros no histórico, se desejado
      // motoAtualizada.historico = motoAtualizada.historico.slice(0, 10);

      motosExistentes[motoIndex] = motoAtualizada;
      await AsyncStorage.setItem(MOTOS_STORAGE_KEY, JSON.stringify(motosExistentes));

      Alert.alert("Evento Registrado", `Novo evento RFID para a moto ${motoAtualizada.placa} no ponto ${selectedPontoRfid} foi registrado com sucesso.`);
      router.push(`/moto/${selectedMotoId}?timestamp=${Date.now()}`); // Redireciona para detalhes da moto, com timestamp para forçar refresh

    } catch (e) {
      Alert.alert("Erro", "Não foi possível registrar o evento RFID.");
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Stack.Screen options={{ title: "Registrar Evento RFID", headerStyle: { backgroundColor: MOTTU_BLACK }, headerTintColor: MOTTU_WHITE, headerTitleStyle: {color: MOTTU_WHITE} }} />
      <Text style={styles.title}>Registrar Evento RFID (Simulado)</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Selecionar Moto:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={selectedMotoId}
            onValueChange={(itemValue) => setSelectedMotoId(itemValue)}
            style={styles.picker}
            dropdownIconColor={MOTTU_GREEN}
          >
            <Picker.Item label="-- Selecione uma Moto --" value={undefined} color={MOTTU_LIGHT_GRAY} />
            {motos.map((moto) => (
              <Picker.Item key={moto.id} label={`${moto.placa} - ${moto.modelo}`} value={moto.id} color={MOTTU_WHITE}/>
            ))}
          </Picker>
        </View>

        <Text style={styles.label}>Selecionar Ponto de Leitura RFID:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={selectedPontoRfid}
            onValueChange={(itemValue) => setSelectedPontoRfid(itemValue)}
            style={styles.picker}
            dropdownIconColor={MOTTU_GREEN}
          >
            {PONTOS_RFID_SIMULADOS.map((ponto) => (
              <Picker.Item key={ponto} label={ponto} value={ponto} color={MOTTU_WHITE}/>
            ))}
          </Picker>
        </View>

        <Text style={styles.label}>Data e Hora do Evento:</Text>
        <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.dateButton}>
            <FontAwesome5 name="calendar-alt" size={18} color={MOTTU_GREEN} />
            <Text style={styles.dateButtonText}>{eventDate.toLocaleString("pt-BR")}</Text>
        </TouchableOpacity>

        {showDatePicker && (
          <DateTimePicker
            testID="datePicker"
            value={eventDate}
            mode={"date"}
            is24Hour={true}
            display="default"
            onChange={onDateChange}
            textColor={MOTTU_WHITE} // Not all props work on all platforms
            accentColor={MOTTU_GREEN} // For Android
          />
        )}
        {showTimePicker && (
          <DateTimePicker
            testID="timePicker"
            value={eventDate}
            mode={"time"}
            is24Hour={true}
            display="default"
            onChange={onTimeChange}
            textColor={MOTTU_WHITE}
            accentColor={MOTTU_GREEN}
          />
        )}
      </View>

      <TouchableOpacity style={styles.buttonPrimary} onPress={handleRegistrarEvento}>
        <FontAwesome5 name="wifi" size={18} color={MOTTU_BLACK} />
        <Text style={styles.buttonPrimaryText}>Registrar Evento</Text>
      </TouchableOpacity>
       <TouchableOpacity 
            style={styles.buttonSecondary}
            onPress={() => router.back()}
        >
            <FontAwesome5 name="times" size={18} color={MOTTU_GREEN} />
            <Text style={styles.buttonSecondaryText}>Cancelar</Text>
        </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    paddingHorizontal: 15,
    paddingVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    textAlign: "center",
    marginBottom: 25,
  },
  card: {
    backgroundColor: MOTTU_GRAY,
    borderRadius: 10,
    padding: 20,
    marginBottom: 25,
  },
  label: {
    fontSize: 17,
    fontWeight: "500",
    color: MOTTU_LIGHT_GRAY,
    marginBottom: 8,
  },
  pickerContainer: {
    backgroundColor: MOTTU_BLACK,
    borderRadius: 8,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: MOTTU_GREEN,
  },
  picker: {
    color: MOTTU_WHITE, // For iOS text color
    height: 50,
  },
  dateButton: {
    backgroundColor: MOTTU_BLACK,
    borderColor: MOTTU_GREEN,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 15,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  dateButtonText: {
    color: MOTTU_GREEN,
    fontSize: 16,
    marginLeft: 10,
  },
  buttonPrimary: {
    backgroundColor: MOTTU_GREEN,
    paddingVertical: 18,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: 15,
  },
  buttonPrimaryText: {
    fontSize: 18,
    color: MOTTU_BLACK,
    fontWeight: "bold",
    marginLeft: 10,
  },
    buttonSecondary: {
    borderColor: MOTTU_GREEN,
    borderWidth: 2,
    paddingVertical: 18,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: 20,
  },
  buttonSecondaryText: {
    fontSize: 18,
    color: MOTTU_GREEN,
    fontWeight: "bold",
    marginLeft: 10,
  },
});

