import { Text, View, StyleSheet, TextInput, Button, ScrollView, Alert } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const MOTOS_STORAGE_KEY = '@MinhasMotos:key';

// Interface para os dados da moto
interface Moto {
  id: string;
  placa: string;
  modelo: string;
  cor: string;
  proprietario: string;
}

export default function CadastrarMotoScreen() {
  const router = useRouter();
  const { edit, id: motoIdParam } = useLocalSearchParams();

  const [placa, setPlaca] = useState('');
  const [modelo, setModelo] = useState('');
  const [cor, setCor] = useState('');
  const [proprietario, setProprietario] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [motoId, setMotoId] = useState<string | null>(null);

  useEffect(() => {
    if (edit === 'true' && typeof motoIdParam === 'string') {
      setIsEditing(true);
      setMotoId(motoIdParam);
      const carregarMotoParaEdicao = async () => {
        try {
          const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
          if (motosSalvas !== null) {
            const motos: Moto[] = JSON.parse(motosSalvas);
            const motoParaEditar = motos.find(m => m.id === motoIdParam);
            if (motoParaEditar) {
              setPlaca(motoParaEditar.placa);
              setModelo(motoParaEditar.modelo);
              setCor(motoParaEditar.cor);
              setProprietario(motoParaEditar.proprietario);
            }
          }
        } catch (e) {
          Alert.alert('Erro', 'Não foi possível carregar os dados da moto para edição.');
        }
      };
      carregarMotoParaEdicao();
    }
  }, [edit, motoIdParam]);

  const handleSalvar = async () => {
    if (!placa || !modelo || !cor || !proprietario) {
      Alert.alert('Erro', 'Todos os campos são obrigatórios.');
      return;
    }

    const novaMoto: Moto = {
      id: isEditing && motoId ? motoId : Date.now().toString(),
      placa,
      modelo,
      cor,
      proprietario,
    };

    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      let motosExistentes: Moto[] = motosSalvas ? JSON.parse(motosSalvas) : [];

      if (isEditing && motoId) {
        // Atualizar moto existente
        motosExistentes = motosExistentes.map(m => (m.id === motoId ? novaMoto : m));
      } else {
        // Adicionar nova moto
        motosExistentes.push(novaMoto);
      }

      await AsyncStorage.setItem(MOTOS_STORAGE_KEY, JSON.stringify(motosExistentes));

      Alert.alert(
        isEditing ? 'Moto Atualizada' : 'Moto Cadastrada',
        `Placa: ${placa}\nModelo: ${modelo}`,
        [
          {
            text: 'OK',
            onPress: () => {
              if (isEditing && motoId) {
                router.replace(`/moto/${motoId}?timestamp=${Date.now()}`); // Adiciona timestamp para forçar atualização na tela de detalhes
              } else {
                router.replace('/(tabs)/motos');
              }
            },
          },
        ]
      );
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível salvar os dados da moto.');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Stack.Screen options={{ title: isEditing ? 'Editar Moto' : 'Cadastrar Nova Moto' }} />
      <Text style={styles.title}>{isEditing ? 'Editar Moto' : 'Cadastrar Nova Moto'}</Text>

      <Text style={styles.label}>Placa:</Text>
      <TextInput
        style={styles.input}
        value={placa}
        onChangeText={setPlaca}
        placeholder="Ex: BRA2E19"
        autoCapitalize="characters"
      />

      <Text style={styles.label}>Modelo:</Text>
      <TextInput
        style={styles.input}
        value={modelo}
        onChangeText={setModelo}
        placeholder="Ex: Honda CB 300R"
      />

      <Text style={styles.label}>Cor:</Text>
      <TextInput
        style={styles.input}
        value={cor}
        onChangeText={setCor}
        placeholder="Ex: Vermelha"
      />

      <Text style={styles.label}>Proprietário:</Text>
      <TextInput
        style={styles.input}
        value={proprietario}
        onChangeText={setProprietario}
        placeholder="Ex: João da Silva"
      />

      <View style={styles.buttonContainer}>
        <Button title={isEditing ? "Salvar Alterações" : "Cadastrar Moto"} onPress={handleSalvar} />
      </View>
      <View style={styles.buttonContainer}>
        <Button title="Cancelar" onPress={() => router.back()} color="grey"/>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    color: '#333',
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    paddingHorizontal: 10,
    paddingVertical: 12,
    fontSize: 16,
    borderRadius: 5,
    marginBottom: 15,
  },
  buttonContainer: {
    marginTop: 10,
  }
});

