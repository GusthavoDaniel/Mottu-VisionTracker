import React, { useState, useCallback, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
  Alert,
  PanResponder,
  Animated,
  Dimensions,
  Modal,
  FlatList,
  TextInput,
} from "react-native";
import { useRouter, useFocusEffect, Stack } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FontAwesome5 } from "@expo/vector-icons";

// Cores (mantendo o padrão Mottu)
const MOTTU_BLACK = "#121212";
const MOTTU_GREEN = "#00EF7F";
const MOTTU_WHITE = "#FFFFFF";
const MOTTU_GRAY = "#333333";
const MOTTU_LIGHT_GRAY = "#A0A0A0";

const MOTOS_STORAGE_KEY = "@MinhasMotos:key";
const PATIO_STATE_STORAGE_KEY = "@PatioState:key";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");
const PATIO_IMAGE_WIDTH = screenWidth * 0.9;
const PATIO_IMAGE_HEIGHT = PATIO_IMAGE_WIDTH * 0.6; // Proporção da imagem do pátio

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  cor: string;
  proprietario: string;
  localizacaoSimulada?: { x: number; y: number; zona?: string };
  historicoLocalizacao?: Array<{
    local: string;
    dataHora: string;
    tipoEvento: string;
  }>;
}

interface MotoNoPatio extends Moto {
  pan: Animated.ValueXY;
  initialX: number;
  initialY: number;
}

// Imagem de fundo simulada para o pátio (poderia ser uma URL ou um require local)
const patioBackgroundImage = {
  uri: "https://img.freepik.com/fotos-premium/estacionamento-vazio-com-linhas-de-marcacao-brancas-vista-superior-aerea_392703-5086.jpg",
};

export default function MapaPatioScreen() {
  const router = useRouter();
  const [motosNoPatio, setMotosNoPatio] = useState<MotoNoPatio[]>([]);
  const [todasAsMotos, setTodasAsMotos] = useState<Moto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [motoSelecionadaParaAdicionar, setMotoSelecionadaParaAdicionar] = useState<Moto | null>(null);
  const [searchText, setSearchText] = useState("");

  const carregarDados = useCallback(async () => {
    setIsLoading(true);
    try {
      const motosSalvasJson = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      const todasMotosCadastradas: Moto[] = motosSalvasJson ? JSON.parse(motosSalvasJson) : [];
      setTodasAsMotos(todasMotosCadastradas);

      const patioStateJson = await AsyncStorage.getItem(PATIO_STATE_STORAGE_KEY);
      if (patioStateJson) {
        const motosPatioSalvas: MotoNoPatio[] = JSON.parse(patioStateJson).map((moto: Moto) => ({
          ...moto,
          pan: new Animated.ValueXY(moto.localizacaoSimulada || { x: 50, y: 50 }),
          initialX: moto.localizacaoSimulada?.x || 50,
          initialY: moto.localizacaoSimulada?.y || 50,
        }));
        setMotosNoPatio(motosPatioSalvas);
      } else {
        // Inicializa com algumas motos mockadas no pátio se não houver estado salvo
        const motosIniciaisNoPatio = todasMotosCadastradas.slice(0, 2).map((moto, index) => ({
          ...moto,
          localizacaoSimulada: { x: 50 + index * 80, y: 50 },
          pan: new Animated.ValueXY({ x: 50 + index * 80, y: 50 }),
          initialX: 50 + index * 80,
          initialY: 50,
        }));
        setMotosNoPatio(motosIniciaisNoPatio);
        await salvarEstadoPatio(motosIniciaisNoPatio);
      }
    } catch (e) {
      Alert.alert("Erro", "Não foi possível carregar os dados do pátio.");
    }
    setIsLoading(false);
  }, []);

  useFocusEffect(carregarDados);

  const salvarEstadoPatio = async (estadoAtualMotos: MotoNoPatio[]) => {
    try {
      const estadoParaSalvar = estadoAtualMotos.map(moto => ({
        ...moto,
        localizacaoSimulada: { x: moto.initialX, y: moto.initialY, zona: calcularZona(moto.initialX, moto.initialY) },
        // Não salvamos o `pan` diretamente, apenas as coordenadas
      }));
      await AsyncStorage.setItem(PATIO_STATE_STORAGE_KEY, JSON.stringify(estadoParaSalvar));
      
      // Atualizar também a lista geral de motos com a nova localização
      const motosGeraisAtualizadas = todasAsMotos.map(mg => {
        const motoNoPatioCorrespondente = estadoParaSalvar.find(mp => mp.id === mg.id);
        if (motoNoPatioCorrespondente) {
          return { ...mg, localizacaoSimulada: motoNoPatioCorrespondente.localizacaoSimulada };
        }
        return mg;
      });
      await AsyncStorage.setItem(MOTOS_STORAGE_KEY, JSON.stringify(motosGeraisAtualizadas));
      setTodasAsMotos(motosGeraisAtualizadas); // Atualiza o estado local de todas as motos

    } catch (e) {
      console.error("Erro ao salvar estado do pátio:", e);
      Alert.alert("Erro", "Não foi possível salvar o estado do pátio.");
    }
  };

  const calcularZona = (x: number, y: number): string => {
    if (y < PATIO_IMAGE_HEIGHT / 2) {
      return x < PATIO_IMAGE_WIDTH / 2 ? "Setor A (Noroeste)" : "Setor B (Nordeste)";
    } else {
      return x < PATIO_IMAGE_WIDTH / 2 ? "Setor C (Sudoeste)" : "Setor D (Sudeste)";
    }
  };

  const criarPanResponder = (moto: MotoNoPatio) =>
    PanResponder.create({
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        moto.pan.setOffset({
          x: moto.pan.x._value,
          y: moto.pan.y._value,
        });
        moto.pan.setValue({ x: 0, y: 0 });
      },
      onPanResponderMove: Animated.event([null, { dx: moto.pan.x, dy: moto.pan.y }], { useNativeDriver: false }),
      onPanResponderRelease: (e, gesture) => {
        moto.pan.flattenOffset();
        let newX = moto.initialX + gesture.dx;
        let newY = moto.initialY + gesture.dy;

        // Limitar o movimento dentro da área da imagem do pátio
        newX = Math.max(0, Math.min(newX, PATIO_IMAGE_WIDTH - 60)); // 60 é a largura do ícone da moto
        newY = Math.max(0, Math.min(newY, PATIO_IMAGE_HEIGHT - 40)); // 40 é a altura do ícone

        moto.initialX = newX;
        moto.initialY = newY;
        moto.pan.setValue({ x: newX, y: newY }); // Atualiza a posição visual final
        
        const novasMotosNoPatio = motosNoPatio.map(m => 
          m.id === moto.id ? { ...moto, initialX: newX, initialY: newY, localizacaoSimulada: {x: newX, y: newY, zona: calcularZona(newX, newY)} } : m
        );
        setMotosNoPatio(novasMotosNoPatio);
        salvarEstadoPatio(novasMotosNoPatio);
        Alert.alert("Moto Movida!", `Moto ${moto.placa} movida para ${calcularZona(newX, newY)}.`);
      },
    });

  const panResponders = useRef<{[key: string]: any}>({});
  useEffect(() => {
    motosNoPatio.forEach(moto => {
      if (!panResponders.current[moto.id]) {
        panResponders.current[moto.id] = criarPanResponder(moto);
      }
    });
  }, [motosNoPatio]);

  const adicionarMotoAoPatio = () => {
    if (!motoSelecionadaParaAdicionar) {
      Alert.alert("Erro", "Nenhuma moto selecionada.");
      return;
    }
    if (motosNoPatio.find(m => m.id === motoSelecionadaParaAdicionar.id)){
      Alert.alert("Atenção", "Esta moto já está no pátio.");
      setModalVisible(false);
      setMotoSelecionadaParaAdicionar(null);
      return;
    }

    const novaPosicao = { x: 20, y: 20 }; // Posição inicial padrão para novas motos
    const novaMotoParaPatio: MotoNoPatio = {
      ...motoSelecionadaParaAdicionar,
      localizacaoSimulada: { ...novaPosicao, zona: calcularZona(novaPosicao.x, novaPosicao.y) },
      pan: new Animated.ValueXY(novaPosicao),
      initialX: novaPosicao.x,
      initialY: novaPosicao.y,
    };
    panResponders.current[novaMotoParaPatio.id] = criarPanResponder(novaMotoParaPatio);
    
    const novasMotos = [...motosNoPatio, novaMotoParaPatio];
    setMotosNoPatio(novasMotos);
    salvarEstadoPatio(novasMotos);
    Alert.alert("Moto Adicionada!", `Moto ${novaMotoParaPatio.placa} adicionada ao pátio em ${calcularZona(novaPosicao.x, novaPosicao.y)}.`);
    setModalVisible(false);
    setMotoSelecionadaParaAdicionar(null);
    setSearchText("");
  };

  const motosDisponiveisParaAdicionar = todasAsMotos.filter(
    (moto) =>
      !motosNoPatio.some((mp) => mp.id === moto.id) &&
      (moto.placa.toLowerCase().includes(searchText.toLowerCase()) ||
        moto.modelo.toLowerCase().includes(searchText.toLowerCase()))
  );

  if (isLoading) {
    return <View style={styles.loadingContainer}><Text style={{color: MOTTU_WHITE}}>Carregando Mapa do Pátio...</Text></View>;
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: "Mapa do Pátio (Simulado)", headerStyle: { backgroundColor: MOTTU_BLACK }, headerTintColor: MOTTU_WHITE, headerTitleStyle: {color: MOTTU_WHITE} }} />
      <Text style={styles.title}>Visão Simulada do Pátio</Text>
      <Text style={styles.subtitle}>Arraste as motos para reposicionar. Pressione "+" para adicionar.</Text>

      <View style={styles.patioContainer}>
        <ImageBackground source={patioBackgroundImage} style={styles.patioImage} resizeMode="cover">
          {motosNoPatio.map((moto) => (
            <Animated.View
              key={moto.id}
              style={[
                {
                  position: "absolute",
                  left: moto.pan.x,
                  top: moto.pan.y,
                },
              ]}
              {...(panResponders.current[moto.id]?.panHandlers || {})}
            >
              <View style={styles.motoIconContainer}>
                <FontAwesome5 name="motorcycle" size={30} color={MOTTU_GREEN} />
                <Text style={styles.motoPlacaText}>{moto.placa.substring(0,3)}</Text>
              </View>
            </Animated.View>
          ))}
        </ImageBackground>
      </View>

      <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
        <FontAwesome5 name="plus" size={24} color={MOTTU_BLACK} />
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
          setMotoSelecionadaParaAdicionar(null);
          setSearchText("");
        }}
      >
        <View style={styles.modalCenteredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalTitle}>Adicionar Moto ao Pátio</Text>
            <TextInput
              style={styles.searchInput}
              placeholder="Buscar placa ou modelo..."
              placeholderTextColor={MOTTU_LIGHT_GRAY}
              value={searchText}
              onChangeText={setSearchText}
            />
            <FlatList
              data={motosDisponiveisParaAdicionar}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity 
                  style={[
                    styles.motoSelectItem,
                    motoSelecionadaParaAdicionar?.id === item.id && styles.motoSelected
                  ]}
                  onPress={() => setMotoSelecionadaParaAdicionar(item)}
                >
                  <Text style={styles.motoSelectItemText}>{item.placa} - {item.modelo}</Text>
                </TouchableOpacity>
              )}
              ListEmptyComponent={<Text style={styles.emptyListText}>Nenhuma moto disponível ou encontrada.</Text>}
              style={{maxHeight: screenHeight * 0.3}}
            />
            <View style={styles.modalButtonContainer}>
              <TouchableOpacity
                style={[styles.modalButton, styles.buttonConfirm]}
                onPress={adicionarMotoAoPatio}
                disabled={!motoSelecionadaParaAdicionar}
              >
                <Text style={styles.modalButtonText}>Confirmar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.buttonCancel]}
                onPress={() => {
                  setModalVisible(!modalVisible);
                  setMotoSelecionadaParaAdicionar(null);
                  setSearchText("");
                }}
              >
                <Text style={styles.modalButtonText}>Cancelar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      <View style={styles.statsContainer}>
          <Text style={styles.statsText}>Motos no Pátio: {motosNoPatio.length}</Text>
          {/* Adicionar mais estatísticas aqui, como vagas disponíveis/ocupadas se tivéssemos um layout de vagas fixo */}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    alignItems: "center",
    paddingVertical: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: MOTTU_LIGHT_GRAY,
    marginBottom: 20,
    textAlign: "center",
  },
  patioContainer: {
    width: PATIO_IMAGE_WIDTH,
    height: PATIO_IMAGE_HEIGHT,
    backgroundColor: MOTTU_GRAY, // Cor de fundo caso a imagem não carregue
    borderRadius: 10,
    overflow: "hidden", // Garante que as motos não saiam da área da imagem
    borderWidth: 2,
    borderColor: MOTTU_GREEN,
  },
  patioImage: {
    width: "100%",
    height: "100%",
  },
  motoIconContainer: {
    width: 60,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
    borderRadius: 5,
  },
  motoPlacaText: {
    color: MOTTU_WHITE,
    fontSize: 10,
    fontWeight: "bold",
  },
  addButton: {
    position: "absolute",
    bottom: 90,
    right: 30,
    backgroundColor: MOTTU_GREEN,
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  modalCenteredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.7)",
  },
  modalView: {
    width: screenWidth * 0.9,
    margin: 20,
    backgroundColor: MOTTU_GRAY,
    borderRadius: 20,
    padding: 25,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    marginBottom: 15,
  },
  searchInput: {
    width: "100%",
    height: 45,
    backgroundColor: MOTTU_BLACK,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    color: MOTTU_WHITE,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: MOTTU_GREEN,
  },
  motoSelectItem: {
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: MOTTU_BLACK,
    width: "100%",
  },
  motoSelected: {
    backgroundColor: MOTTU_GREEN,
  },
  motoSelectItemText: {
    fontSize: 16,
    color: MOTTU_WHITE,
  },
  emptyListText: {
    textAlign: "center",
    color: MOTTU_LIGHT_GRAY,
    marginTop: 10,
  },
  modalButtonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 20,
  },
  modalButton: {
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
    elevation: 2,
    minWidth: 120,
    alignItems: "center",
  },
  buttonConfirm: {
    backgroundColor: MOTTU_GREEN,
  },
  buttonCancel: {
    backgroundColor: MOTTU_RED,
  },
  modalButtonText: {
    color: MOTTU_BLACK,
    fontWeight: "bold",
    textAlign: "center",
    fontSize: 16,
  },
  statsContainer: {
      position: "absolute",
      bottom: 20,
      left: 20,
      backgroundColor: "rgba(0,0,0,0.7)",
      padding: 10,
      borderRadius: 5,
  },
  statsText: {
      color: MOTTU_WHITE,
      fontSize: 14,
  }
});


