import { Text, View, StyleSheet } from 'react-native';
import { Link } from 'expo-router';

export default function ConfiguracoesScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Configurações</Text>
      <Text>Informações sobre o app.</Text>
      <Text>Nome: [Seu Nome Completo Aqui]</Text>
      <Text>RM: [Seu RM Aqui]</Text>
      <Text style={{marginTop: 20}}>Este é um protótipo para mapeamento de pátio.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

