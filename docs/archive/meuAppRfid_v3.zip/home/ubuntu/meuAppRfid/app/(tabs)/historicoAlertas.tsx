import React, { useState, useCallback } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from "react-native";
import { useRouter, useFocusEffect, Stack } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FontAwesome5 } from "@expo/vector-icons";

// Cores (mantendo o padrão Mottu)
const MOTTU_BLACK = "#121212";
const MOTTU_GREEN = "#00EF7F";
const MOTTU_WHITE = "#FFFFFF";
const MOTTU_GRAY = "#333333";
const MOTTU_LIGHT_GRAY = "#A0A0A0";
const MOTTU_RED = "#FF6B6B"; // Para alertas críticos
const MOTTU_YELLOW = "#FFD166"; // Para alertas de aviso

const ALERTAS_STORAGE_KEY = "@MeusAlertasRfid:key";

interface Alerta {
  id: string;
  tipo: "Movimentação Suspeita" | "Parada Prolongada" | "Bateria Baixa RFID" | "Manutenção Necessária" | "Fora de Rota";
  motoPlaca: string;
  localizacao?: string;
  dataHora: string;
  lido: boolean;
  descricao?: string;
}

// Função para gerar alertas mockados (para demonstração)
const gerarAlertasMockados = (): Alerta[] => {
  const placasMock = ["ABC1D34", "XYZ5G67", "LMN3J01", "DEF4H66", "QWE7R89"];
  const tiposAlerta: Alerta["tipo"][] = ["Movimentação Suspeita", "Parada Prolongada", "Bateria Baixa RFID", "Manutenção Necessária", "Fora de Rota"];
  const locaisMock = ["Pátio A - Setor 3", "Portaria Principal", "Oficina Bloco B", "Zona de Carga Leste", "Estacionamento Visitantes"];
  
  const alertas: Alerta[] = [];
  for (let i = 0; i < 7; i++) {
    const placa = placasMock[Math.floor(Math.random() * placasMock.length)];
    const tipo = tiposAlerta[Math.floor(Math.random() * tiposAlerta.length)];
    const local = locaisMock[Math.floor(Math.random() * locaisMock.length)];
    const data = new Date(Date.now() - Math.random() * 1000 * 60 * 60 * 24 * 5); // Alertas nos últimos 5 dias

    alertas.push({
      id: `alerta_${Date.now()}_${i}`,
      tipo: tipo,
      motoPlaca: placa,
      localizacao: local,
      dataHora: data.toLocaleString("pt-BR"),
      lido: Math.random() > 0.5,
      descricao: `Detalhes adicionais sobre o alerta para a moto ${placa} em ${local}. Tipo: ${tipo}.`
    });
  }
  return alertas.sort((a,b) => new Date(b.dataHora.split(", ")[0].split("/").reverse().join("-") + "T" + b.dataHora.split(", ")[1]).getTime() - new Date(a.dataHora.split(", ")[0].split("/").reverse().join("-") + "T" + a.dataHora.split(", ")[1]).getTime());
};

export default function HistoricoAlertasScreen() {
  const router = useRouter();
  const [alertas, setAlertas] = useState<Alerta[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const carregarAlertas = useCallback(async () => {
    setIsLoading(true);
    try {
      let alertasSalvos = await AsyncStorage.getItem(ALERTAS_STORAGE_KEY);
      if (alertasSalvos === null) {
        // Se não houver alertas salvos, gera mockados e salva
        const mockAlerts = gerarAlertasMockados();
        await AsyncStorage.setItem(ALERTAS_STORAGE_KEY, JSON.stringify(mockAlerts));
        alertasSalvos = JSON.stringify(mockAlerts);
      }
      setAlertas(JSON.parse(alertasSalvos || "[]"));
    } catch (e) {
      Alert.alert("Erro", "Não foi possível carregar os alertas.");
      setAlertas([]);
    }
    setIsLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarAlertas();
    }, [carregarAlertas])
  );

  const marcarComoLidoDeslido = async (idAlerta: string) => {
    try {
      const novosAlertas = alertas.map(alerta => 
        alerta.id === idAlerta ? { ...alerta, lido: !alerta.lido } : alerta
      );
      setAlertas(novosAlertas);
      await AsyncStorage.setItem(ALERTAS_STORAGE_KEY, JSON.stringify(novosAlertas));
    } catch (e) {
      Alert.alert("Erro", "Não foi possível atualizar o status do alerta.");
    }
  };

  const getIconForAlerta = (tipo: Alerta["tipo"]) => {
    switch (tipo) {
      case "Movimentação Suspeita": return { name: "user-secret", color: MOTTU_RED };
      case "Parada Prolongada": return { name: "parking", color: MOTTU_YELLOW };
      case "Bateria Baixa RFID": return { name: "battery-quarter", color: MOTTU_YELLOW };
      case "Manutenção Necessária": return { name: "tools", color: MOTTU_RED };
      case "Fora de Rota": return { name: "route", color: MOTTU_YELLOW };
      default: return { name: "exclamation-triangle", color: MOTTU_LIGHT_GRAY };
    }
  };

  const renderItem = ({ item }: { item: Alerta }) => {
    const iconInfo = getIconForAlerta(item.tipo);
    return (
      <TouchableOpacity 
        style={[styles.alertaItem, item.lido && styles.alertaLido]} 
        onPress={() => Alert.alert(item.tipo, `${item.descricao}\nData: ${item.dataHora}\nMoto: ${item.motoPlaca}\nLocal: ${item.localizacao}`)}
        onLongPress={() => marcarComoLidoDeslido(item.id)}
      >
        <FontAwesome5 name={iconInfo.name} size={24} color={iconInfo.color} style={styles.alertaIcon} />
        <View style={styles.alertaTextContainer}>
          <Text style={styles.alertaTipo}>{item.tipo} - {item.motoPlaca}</Text>
          <Text style={styles.alertaDetalhe}>Local: {item.localizacao || "N/A"}</Text>
          <Text style={styles.alertaDetalhe}>Data: {item.dataHora}</Text>
        </View>
        <FontAwesome5 name={item.lido ? "check-circle" : "circle"} size={20} color={item.lido ? MOTTU_GREEN : MOTTU_LIGHT_GRAY} />
      </TouchableOpacity>
    );
  };

  if (isLoading) {
    return <View style={styles.loadingContainer}><Text style={{color: MOTTU_WHITE}}>Carregando Histórico de Alertas...</Text></View>;
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: "Histórico de Alertas", headerStyle: { backgroundColor: MOTTU_BLACK }, headerTintColor: MOTTU_WHITE, headerTitleStyle: {color: MOTTU_WHITE} }} />
      <Text style={styles.title}>Histórico de Alertas (RFID Simulado)</Text>
      <FlatList
        data={alertas}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        ListEmptyComponent={<Text style={styles.emptyText}>Nenhum alerta registrado.</Text>}
        contentContainerStyle={alertas.length === 0 ? styles.emptyListContainer : {paddingBottom: 20}}
      />
      <Text style={styles.hintText}>Pressione e segure um alerta para marcar como lido/não lido.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    paddingHorizontal: 15,
    paddingVertical: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    textAlign: "center",
    marginBottom: 20,
  },
  alertaItem: {
    backgroundColor: MOTTU_GRAY,
    padding: 15,
    borderRadius: 10,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    borderLeftWidth: 5,
    borderLeftColor: MOTTU_YELLOW, // Default color, can be overridden by icon color
  },
  alertaLido: {
    backgroundColor: MOTTU_BLACK, // Darker for read items
    opacity: 0.7,
    borderLeftColor: MOTTU_GREEN,
  },
  alertaIcon: {
    marginRight: 15,
  },
  alertaTextContainer: {
    flex: 1,
  },
  alertaTipo: {
    fontSize: 17,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    marginBottom: 3,
  },
  alertaDetalhe: {
    fontSize: 14,
    color: MOTTU_LIGHT_GRAY,
  },
  emptyText: {
    textAlign: "center",
    fontSize: 17,
    color: MOTTU_LIGHT_GRAY,
    marginTop: 50,
  },
  emptyListContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  hintText: {
    textAlign: "center",
    fontSize: 13,
    color: MOTTU_LIGHT_GRAY,
    marginTop: 10,
    fontStyle: "italic",
  }
});

