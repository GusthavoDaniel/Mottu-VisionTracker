import { Text, View, StyleSheet, Button, TouchableOpacity } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons'; // Para ícones, se necessário

// Cores inspiradas no site da Mottu
const MOTTU_BLACK = '#121212'; // Um preto não tão absoluto, mais suave
const MOTTU_GREEN = '#00EF7F'; // Verde vibrante característico
const MOTTU_WHITE = '#FFFFFF';
const MOTTU_GRAY = '#333333'; // Para cards ou elementos secundários
const MOTTU_LIGHT_GRAY = '#A0A0A0'; // Para texto secundário

export default function DashboardScreen() {
  const router = useRouter();

  // Dados mockados
  const numeroMotos = 15;
  const alertas = [
    { id: 1, mensagem: 'Moto XYZ1234 parada há mais de 24h na Zona Leste.' },
    { id: 2, mensagem: 'Bateria baixa na moto ABC9876.' },
    { id: 3, mensagem: 'Manutenção preventiva agendada para JKL5678.' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Dashboard Mottu Pátio</Text>
      
      <View style={styles.metricContainer}>
        <FontAwesome5 name="motorcycle" size={40} color={MOTTU_GREEN} />
        <Text style={styles.metricValue}>{numeroMotos}</Text>
        <Text style={styles.metricLabel}>Motos no Pátio</Text>
      </View>

      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Alertas e Avisos</Text>
        {alertas.map((alerta) => (
          <View key={alerta.id} style={styles.alertaItem}>
            <FontAwesome5 name="exclamation-triangle" size={18} color={MOTTU_GREEN} style={styles.alertaIcon} />
            <Text style={styles.alertaMensagem}>{alerta.mensagem}</Text>
          </View>
        ))}
        {alertas.length === 0 && <Text style={{color: MOTTU_LIGHT_GRAY}}>Nenhum alerta no momento.</Text>}
      </View>

      <TouchableOpacity 
        style={styles.buttonPrimary}
        onPress={() => router.push('/(tabs)/motos')}
      >
        <FontAwesome5 name="list-ul" size={18} color={MOTTU_BLACK} />
        <Text style={styles.buttonPrimaryText}>Ver Lista de Motos</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.buttonSecondary}
        onPress={() => router.push('/cadastrarMoto')}
      >
        <FontAwesome5 name="plus-circle" size={18} color={MOTTU_GREEN} />
        <Text style={styles.buttonSecondaryText}>Cadastrar Nova Moto</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    backgroundColor: MOTTU_BLACK,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: MOTTU_WHITE,
    marginBottom: 30,
    textAlign: 'center',
    marginTop: 20,
  },
  metricContainer: {
    backgroundColor: MOTTU_GRAY,
    padding: 25,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 30,
    shadowColor: MOTTU_GREEN,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 10,
    borderWidth: 1,
    borderColor: MOTTU_GREEN,
  },
  metricValue: {
    fontSize: 48,
    fontWeight: 'bold',
    color: MOTTU_GREEN,
    marginTop: 10,
  },
  metricLabel: {
    fontSize: 18,
    color: MOTTU_LIGHT_GRAY,
    marginTop: 5,
  },
  sectionContainer: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: MOTTU_WHITE,
    marginBottom: 15,
  },
  alertaItem: {
    backgroundColor: MOTTU_GRAY,
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: MOTTU_GREEN,
  },
  alertaIcon: {
    marginRight: 10,
  },
  alertaMensagem: {
    fontSize: 15,
    color: MOTTU_WHITE,
    flexShrink: 1,
  },
  buttonPrimary: {
    backgroundColor: MOTTU_GREEN,
    paddingVertical: 18,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginBottom: 15,
  },
  buttonPrimaryText: {
    fontSize: 18,
    color: MOTTU_BLACK,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  buttonSecondary: {
    borderColor: MOTTU_GREEN,
    borderWidth: 2,
    paddingVertical: 18,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  buttonSecondaryText: {
    fontSize: 18,
    color: MOTTU_GREEN,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

