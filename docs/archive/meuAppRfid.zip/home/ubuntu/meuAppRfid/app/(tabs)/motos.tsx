import { Text, View, StyleSheet, FlatList, TouchableOpacity, Button, Alert } from 'react-native';
import { Link, useRouter, useFocusEffect } from 'expo-router';
import { useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const MOTOS_STORAGE_KEY = '@MinhasMotos:key';

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  cor: string;
  proprietario: string;
  // Adicionando ultimaLocalizacao para manter a simulação visual, mesmo que não seja persistida no formulário principal
  ultimaLocalizacao?: string; 
}

export default function MotosScreen() {
  const router = useRouter();
  const [motos, setMotos] = useState<Moto[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const carregarMotos = useCallback(async () => {
    setIsLoading(true);
    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      if (motosSalvas !== null) {
        const motosParseadas: Moto[] = JSON.parse(motosSalvas);
        // Adicionar dados mockados de localização se não existirem, para manter a UI consistente com o protótipo inicial
        const motosComLocalizacao = motosParseadas.map(moto => ({
          ...moto,
          ultimaLocalizacao: moto.ultimaLocalizacao || `Pátio ${String.fromCharCode(65 + Math.floor(Math.random() * 3))} - Seção ${Math.floor(Math.random() * 5) + 1}`
        }));
        setMotos(motosComLocalizacao);
      } else {
        setMotos([]); // Nenhuma moto salva ainda
      }
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível carregar as motos salvas.');
      setMotos([]); // Define como vazio em caso de erro
    }
    setIsLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarMotos();
    }, [carregarMotos])
  );

  const renderItem = ({ item }: { item: Moto }) => (
    <TouchableOpacity onPress={() => router.push(`/moto/${item.id}`)} style={styles.motoItem}>
      <Text style={styles.motoPlaca}>{item.placa} - {item.modelo}</Text>
      <Text>Proprietário: {item.proprietario}</Text>
      <Text>Última Localização (Simulada): {item.ultimaLocalizacao || 'N/A'}</Text>
    </TouchableOpacity>
  );

  if (isLoading) {
    return (
      <View style={styles.containerCentered}>
        <Text>Carregando motos...</Text>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.title}>Lista de Motos</Text>
        <Button 
          title="Adicionar Nova" 
          onPress={() => router.push('/cadastrarMoto')} 
        />
      </View>
      <FlatList
        data={motos}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        ListEmptyComponent={<Text style={styles.emptyText}>Nenhuma moto cadastrada. Clique em "Adicionar Nova" para começar.</Text>}
        contentContainerStyle={motos.length === 0 ? styles.emptyListContainer : null}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  containerCentered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  motoItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
  motoPlaca: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#666',
  },
  emptyListContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  }
});

