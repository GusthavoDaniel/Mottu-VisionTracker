import { Text, View, StyleSheet, Button } from 'react-native';
import { Link, useRouter } from 'expo-router';

export default function DashboardScreen() {
  const router = useRouter();

  // Dados mockados
  const numeroMotos = 15;
  const alertas = [
    { id: 1, mensagem: 'Moto XYZ1234 parada há mais de 24h na Zona Leste.' },
    { id: 2, mensagem: 'Bateria baixa na moto ABC9876.' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Dashboard do Pátio</Text>
      
      <View style={styles.metricContainer}>
        <Text style={styles.metricValue}>{numeroMotos}</Text>
        <Text style={styles.metricLabel}>Motos no Pátio</Text>
      </View>

      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Alertas Recentes (Simulado)</Text>
        {alertas.map((alerta) => (
          <View key={alerta.id} style={styles.alertaItem}>
            <Text>{alerta.mensagem}</Text>
          </View>
        ))}
        {alertas.length === 0 && <Text>Nenhum alerta no momento.</Text>}
      </View>

      <View style={styles.buttonContainer}>
        <Button 
          title="Ver Lista de Motos" 
          onPress={() => router.push('/motos')} 
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button 
          title="Cadastrar Nova Moto" 
          onPress={() => router.push('/cadastrarMoto')} 
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  metricContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  metricValue: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#333',
  },
  metricLabel: {
    fontSize: 16,
    color: '#666',
  },
  sectionContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertaItem: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 4,
    marginBottom: 5,
    borderLeftWidth: 3,
    borderLeftColor: 'orange',
  },
  buttonContainer: {
    marginTop: 10,
  }
});

