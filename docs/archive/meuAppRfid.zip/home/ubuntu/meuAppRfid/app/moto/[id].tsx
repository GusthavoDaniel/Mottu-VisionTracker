import { Text, View, StyleSheet, Button, ScrollView } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useState, useEffect } from 'react';

// Dados mockados para simular busca
const MOTOS_MOCK = [
  { id: '1', placa: 'BRA2E19', modelo: 'Honda CB 300R', cor: 'Vermelha', proprietario: 'João Silva', ultimaLocalizacao: 'Pátio A - Seção 1', historico: [{ data: '2024-05-13 10:00', local: 'Entrada Pátio' }, { data: '2024-05-13 14:30', local: 'Pátio A - Seção 1' }] },
  { id: '2', placa: 'XYZ1234', modelo: 'Yamaha Fazer 250', cor: 'Preta', proprietario: 'Maria Oliveira', ultimaLocalizacao: 'Pátio B - Seção 3', historico: [{ data: '2024-05-12 08:00', local: 'Portaria' }, { data: '2024-05-12 18:00', local: 'Pátio B - Seção 3' }] },
  { id: '3', placa: 'ABC9876', modelo: 'BMW G310R', cor: 'Azul', proprietario: 'Carlos Pereira', ultimaLocalizacao: 'Entrada Principal', historico: [] },
  { id: '4', placa: 'DEF5678', modelo: 'Kawasaki Ninja 400', cor: 'Verde', proprietario: 'Ana Costa', ultimaLocalizacao: 'Oficina', historico: [{data: '2024-05-13 16:00', local: 'Oficina'}] },
];

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  cor: string;
  proprietario: string;
  ultimaLocalizacao: string;
  historico: Array<{data: string, local: string}>;
}

export default function MotoDetalhesScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [moto, setMoto] = useState<Moto | null>(null);

  useEffect(() => {
    if (id) {
      const motoEncontrada = MOTOS_MOCK.find(m => m.id === id);
      setMoto(motoEncontrada || null);
    }
  }, [id]);

  if (!moto) {
    return (
      <View style={styles.container}>
        <Text>Moto não encontrada.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Stack.Screen options={{ title: `Moto ${moto.placa}` }} />
      <Text style={styles.title}>Detalhes da Moto</Text>
      
      <View style={styles.detailItem}>
        <Text style={styles.label}>Placa:</Text>
        <Text style={styles.value}>{moto.placa}</Text>
      </View>
      <View style={styles.detailItem}>
        <Text style={styles.label}>Modelo:</Text>
        <Text style={styles.value}>{moto.modelo}</Text>
      </View>
      <View style={styles.detailItem}>
        <Text style={styles.label}>Cor:</Text>
        <Text style={styles.value}>{moto.cor}</Text>
      </View>
      <View style={styles.detailItem}>
        <Text style={styles.label}>Proprietário:</Text>
        <Text style={styles.value}>{moto.proprietario}</Text>
      </View>
      <View style={styles.detailItem}>
        <Text style={styles.label}>Última Localização (Simulada):</Text>
        <Text style={styles.value}>{moto.ultimaLocalizacao}</Text>
      </View>

      <Text style={styles.sectionTitle}>Histórico de Localizações (Simulado)</Text>
      {moto.historico.length > 0 ? (
        moto.historico.map((item, index) => (
          <View key={index} style={styles.historyItem}>
            <Text>{item.data} - {item.local}</Text>
          </View>
        ))
      ) : (
        <Text>Nenhum histórico de localização disponível.</Text>
      )}

      <View style={styles.buttonContainer}>
        <Button 
          title="Editar Moto"
          onPress={() => router.push(`/cadastrarMoto?edit=true&id=${moto.id}`)} // Passa parâmetro para indicar edição
        />
      </View>
       <View style={styles.buttonContainer}>
        <Button 
          title="Voltar para Lista"
          onPress={() => router.back()}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  detailItem: {
    flexDirection: 'row',
    marginBottom: 10,
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
    color: '#333',
  },
  value: {
    fontSize: 16,
    color: '#555',
    flexShrink: 1, 
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  historyItem: {
    backgroundColor: '#e9e9e9',
    padding: 8,
    borderRadius: 4,
    marginBottom: 5,
  },
  buttonContainer: {
    marginTop: 15,
  }
});

