import { Text, View, StyleSheet, FlatList, TouchableOpacity, Button, TextInput, Alert } from "react-native";
import { Link, useRouter, useFocusEffect } from "expo-router";
import { useState, useCallback, useMemo } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FontAwesome5 } from "@expo/vector-icons";

// Cores (mantendo o padrão Mottu)
const MOTTU_BLACK = "#121212";
const MOTTU_GREEN = "#00EF7F";
const MOTTU_WHITE = "#FFFFFF";
const MOTTU_GRAY = "#333333";
const MOTTU_LIGHT_GRAY = "#A0A0A0";

const MOTOS_STORAGE_KEY = "@MinhasMotos:key";

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  cor: string;
  proprietario: string;
  ultimaLocalizacao?: string;
}

export default function MotosScreen() {
  const router = useRouter();
  const [motos, setMotos] = useState<Moto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const carregarMotos = useCallback(async () => {
    setIsLoading(true);
    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      if (motosSalvas !== null) {
        const motosParseadas: Moto[] = JSON.parse(motosSalvas);
        const motosComLocalizacao = motosParseadas.map(moto => ({
          ...moto,
          ultimaLocalizacao: moto.ultimaLocalizacao || `Pátio ${String.fromCharCode(65 + Math.floor(Math.random() * 3))} - Seção ${Math.floor(Math.random() * 5) + 1}`
        }));
        setMotos(motosComLocalizacao);
      } else {
        setMotos([]);
      }
    } catch (e) {
      Alert.alert("Erro", "Não foi possível carregar as motos salvas.");
      setMotos([]);
    }
    setIsLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarMotos();
    }, [carregarMotos])
  );

  const filteredMotos = useMemo(() => {
    if (!searchTerm) {
      return motos;
    }
    return motos.filter(
      (moto) =>
        moto.placa.toLowerCase().includes(searchTerm.toLowerCase()) ||
        moto.modelo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (moto.proprietario && moto.proprietario.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [motos, searchTerm]);

  const renderItem = ({ item }: { item: Moto }) => (
    <TouchableOpacity onPress={() => router.push(`/moto/${item.id}`)} style={styles.motoItem}>
      <View style={styles.motoItemHeader}>
        <FontAwesome5 name="motorcycle" size={20} color={MOTTU_GREEN} />
        <Text style={styles.motoPlaca}>{item.placa} - {item.modelo}</Text>
      </View>
      <Text style={styles.motoDetailText}>Proprietário: {item.proprietario}</Text>
      <Text style={styles.motoDetailText}>Última Localização (Simulada): {item.ultimaLocalizacao || "N/A"}</Text>
    </TouchableOpacity>
  );

  if (isLoading) {
    return (
      <View style={styles.containerCentered}>
        <Text style={{color: MOTTU_WHITE}}>Carregando motos...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.title}>Lista de Motos</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => router.push("/cadastrarMoto")}
        >
          <FontAwesome5 name="plus" size={16} color={MOTTU_BLACK} />
          <Text style={styles.addButtonText}>Adicionar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <FontAwesome5 name="search" size={18} color={MOTTU_LIGHT_GRAY} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar por Placa, Modelo ou Proprietário..."
          placeholderTextColor={MOTTU_LIGHT_GRAY}
          value={searchTerm}
          onChangeText={setSearchTerm}
        />
      </View>

      <FlatList
        data={filteredMotos}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        ListEmptyComponent={
            <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>
                    {searchTerm ? "Nenhuma moto encontrada para sua busca." : "Nenhuma moto cadastrada."}
                </Text>
                {!searchTerm && 
                    <Text style={styles.emptySubText}>Clique em "Adicionar" para começar.</Text>
                }
            </View>
        }
        contentContainerStyle={filteredMotos.length === 0 ? styles.emptyListContainer : {paddingBottom: 20}}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 25,
    backgroundColor: MOTTU_BLACK,
  },
  containerCentered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: MOTTU_BLACK,
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: MOTTU_WHITE,
  },
  addButton: {
    backgroundColor: MOTTU_GREEN,
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
  },
  addButtonText: {
    color: MOTTU_BLACK,
    fontWeight: "bold",
    marginLeft: 8,
    fontSize: 15,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: MOTTU_GRAY,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: MOTTU_WHITE,
  },
  motoItem: {
    backgroundColor: MOTTU_GRAY,
    padding: 15,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: MOTTU_GREEN,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    borderLeftWidth: 4,
    borderLeftColor: MOTTU_GREEN,
  },
  motoItemHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  motoPlaca: {
    fontSize: 17,
    fontWeight: "bold",
    color: MOTTU_WHITE,
    marginLeft: 10,
  },
  motoDetailText: {
    fontSize: 14,
    color: MOTTU_LIGHT_GRAY,
    marginBottom: 3,
  },
  emptyContainer: {
    alignItems: "center",
    marginTop: 60,
  },
  emptyText: {
    textAlign: "center",
    fontSize: 17,
    color: MOTTU_LIGHT_GRAY,
  },
  emptySubText: {
    textAlign: "center",
    fontSize: 15,
    color: MOTTU_GRAY,
    marginTop: 5,
  },
  emptyListContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

