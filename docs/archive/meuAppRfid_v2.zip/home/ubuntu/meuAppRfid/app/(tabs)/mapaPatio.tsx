import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FontAwesome5 } from '@expo/vector-icons';

// Cores (mantendo o padrão Mottu)
const MOTTU_BLACK = '#121212';
const MOTTU_GREEN = '#00EF7F';
const MOTTU_WHITE = '#FFFFFF';
const MOTTU_GRAY = '#333333';
const MOTTU_LIGHT_GRAY = '#A0A0A0';

const MOTOS_STORAGE_KEY = '@MinhasMotos:key';

interface Moto {
  id: string;
  placa: string;
  modelo: string;
  ultimaLocalizacao: string; // Ex: 'Portaria', 'PatioA', 'Oficina'
}

interface PatioZone {
  id: string;
  name: string;
  style: object; // Para posicionamento e dimensões
  motos: Moto[];
}

// Definição simplificada das zonas do pátio
const ZONAS_PATIO_LAYOUT: Omit<PatioZone, 'motos'>[] = [
  { id: 'Portaria', name: 'Portaria / Entrada', style: { top: '5%', left: '35%', width: '30%', height: '10%' } },
  { id: 'PatioA', name: 'Pátio A', style: { top: '20%', left: '5%', width: '40%', height: '30%' } },
  { id: 'PatioB', name: 'Pátio B', style: { top: '20%', left: '55%', width: '40%', height: '30%' } },
  { id: 'Oficina', name: 'Oficina', style: { top: '55%', left: '5%', width: '45%', height: '20%' } },
  { id: 'ZonaCarga', name: 'Zona de Carga', style: { top: '55%', left: '55%', width: '40%', height: '20%' } },
  { id: 'Lavagem', name: 'Lavagem', style: { top: '80%', left: '30%', width: '40%', height: '10%' } },
];

export default function MapaPatioScreen() {
  const router = useRouter();
  const [patioState, setPatioState] = useState<PatioZone[]>(ZONAS_PATIO_LAYOUT.map(z => ({ ...z, motos: [] })));
  const [isLoading, setIsLoading] = useState(true);

  const carregarMotosNoPatio = useCallback(async () => {
    setIsLoading(true);
    try {
      const motosSalvas = await AsyncStorage.getItem(MOTOS_STORAGE_KEY);
      const todasMotos: Moto[] = motosSalvas ? JSON.parse(motosSalvas) : [];
      
      const novoPatioState = ZONAS_PATIO_LAYOUT.map(zonaLayout => {
        const motosNestaZona = todasMotos.filter(moto => 
          moto.ultimaLocalizacao && moto.ultimaLocalizacao.toLowerCase().includes(zonaLayout.id.toLowerCase())
        );
        return { ...zonaLayout, motos: motosNestaZona };
      });
      
      // Agrupar motos não localizadas em uma zona "Desconhecida" ou similar, se necessário
      // Por simplicidade, aqui apenas distribuímos nas zonas definidas.

      setPatioState(novoPatioState);
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível carregar os dados das motos para o mapa.');
    }
    setIsLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarMotosNoPatio();
    }, [carregarMotosNoPatio])
  );

  const renderMotoIcon = (moto: Moto, zonaId: string, index: number) => (
    <TouchableOpacity 
      key={moto.id} 
      style={[styles.motoIcon, { left: `${5 + index * 15}%`, top: `${20 + (index % 3) * 25}%` }]} // Posicionamento simples dentro da zona
      onPress={() => router.push(`/moto/${moto.id}`)}
    >
      <FontAwesome5 name="motorcycle" size={18} color={MOTTU_GREEN} />
      <Text style={styles.motoIconText}>{moto.placa.substring(0,4)}</Text>
    </TouchableOpacity>
  );

  if (isLoading) {
    return <View style={styles.loadingContainer}><Text style={{color: MOTTU_WHITE}}>Carregando Mapa do Pátio...</Text></View>;
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Mapa do Pátio (Simulado)</Text>
      <View style={styles.mapContainer}>
        {patioState.map(zona => (
          <View key={zona.id} style={[styles.zonaPatio, zona.style]}>
            <Text style={styles.zonaNome}>{zona.name} ({zona.motos.length})</Text>
            {zona.motos.map((moto, index) => renderMotoIcon(moto, zona.id, index))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    paddingVertical: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: MOTTU_BLACK,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: MOTTU_WHITE,
    textAlign: 'center',
    marginBottom: 20,
    paddingHorizontal: 15,
  },
  mapContainer: {
    width: '100%',
    height: 600, // Altura fixa para o mapa, ajuste conforme necessário
    backgroundColor: MOTTU_GRAY,
    borderRadius: 10,
    position: 'relative', // Para posicionamento absoluto das zonas
    marginHorizontal: '2.5%',
    alignSelf: 'center',
    maxWidth: 500, // Max width for larger screens
  },
  zonaPatio: {
    position: 'absolute',
    borderWidth: 2,
    borderColor: MOTTU_GREEN,
    borderRadius: 8,
    padding: 5,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  zonaNome: {
    color: MOTTU_WHITE,
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  motoIcon: {
    position: 'absolute', // Para permitir sobreposição e melhor distribuição visual
    alignItems: 'center',
    padding: 2,
  },
  motoIconText: {
    color: MOTTU_GREEN,
    fontSize: 8,
  },
});

